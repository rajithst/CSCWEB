<?php
	include("form.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="login page for the students">
	<meta name="auther" content="Chamith Niroshana">
    <title>Student/Login</title>
    
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-theme.css">
    <link rel="stylesheet" href="css/bootstrap-theme.min.css">
	<link rel="stylesheet" href="css/headerfooter.css">
	<link rel="stylesheet" href="css/newsfeed.css">
	<link rel="stylesheet" href="css/login.css">

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>

<body>
   
	<!-- start of nav bar-->
    <nav class="navbar navbar-custom" role = "navigation">
        <div class="container-fluid">
		    <div class="navbar-header">
			    <a href="#" class="logo pull-left"><img src="img/csc_logo.png" style="width:auto; height:42px;"></a>
			</div>
	    </div>
    </nav>
	
	<!-- start of body -->
	<div class="container-fluid">
	    <div class="row content" id="row">
		    <!-- start of news feed -->
	        <div class="col-md-9 col-sm-12 col-xs-12 text-left">
			    <div id="newsfeed">
				   <div class="col-sm-12 col-xm-12"> <h3>News Feed</h3></div>
				    <div class="col-sm-12 col-xm-12">
					    <div id="nws">
						    <div class="panel panel-default">
						        <div class="panel-heading">News 1</div>
                                <div class="panel-body" id="newsbody">
								    
								    <div id="attach"><a href="">Attachment</a></div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-sm-12 col-xm-12">
					    <div id="nws">
						    <div class="panel panel-default">
						        <div class="panel-heading">News 2</div>
                                <div class="panel-body" id="newsbody">
								    <div id="attach"><a href="">Attachment</a></div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-sm-12 col-xm-12">
					    <div id="nws">
						    <div class="panel panel-default">
						        <div class="panel-heading">News 3</div>
                                <div class="panel-body" id="newsbody">
								    <div id="attach"><a href="">Attachment</a></div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-sm-12 col-xm-12">
					    <div id="nws">
						    <div class="panel panel-default">
						        <div class="panel-heading">News 4</div>
                                <div class="panel-body" id="newsbody">
								    <div id="attach"><a href="">Attachment</a></div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-sm-12 col-xm-12">
					    <div id="nws">
						    <div class="panel panel-default">
						        <div class="panel-heading">News 5</div>
                                <div class="panel-body" id="newsbody">
								    <div id="attach"><a href="">Attachment</a></div>
								</div>
							</div>
						</div>
					</div>
			       <div align="center"> <a href="">Older topics..</a></div>
			    </div>
		    </div>
		
		    <!-- start of student login form -->
		    <div class="col-md-3 col-sm-12 col-xs-12" style="background-color:#e0e0d1; height:690px; margin-top:-10px; margin-bottom:-10px;">
		        <div class="id="student-login" style="margin-top:30px;">
			        <div class="heading" align="center" >
				       <h3 style="margin-right:5px;"><strong>Student Login</strong></h3>
		            </div>
			        <div class="body">
				         <form action="" method="post">
                            <div class="col-md-12 col-sm-12 col-xs-12">
						       <label for="email">User Name:</label></br>
							   <input type="user-name" name="username" class="form-control" id="user-name">
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                               <label for="pwd">Password:</label></br>
							   <input type="password" name="passwrd" class="form-control" id="pwd" >
						    </div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                               <label><input type="checkbox"> Remember me</label>
                            </div>
							<!-- error messege -->
							<div style="margin-left:15px;color:red;"><?php echo $error; ?></div>
						    </br>
                            <div class="col-md-12 col-sm-12 col-xs-12" align="center">
                            <button type="submit" name="Submit" class="btn btn-info" style=" font-weight: bold;">Login</button>
                            </div>
                        </form>
				    </div>
			    </div>
		    </div>
			
		</div>
	</div>
	
	
<!-- start of footer><!-->

    <footer class="container-fluid">
        <div class = "container-fluid">
            <div class="row">
                <div col-md-5 class="footer-content">
                     <ul class="footer-nav">
                        <li>C</li> <li>O</li> <li>M</li> <li>P</li> <li>U</li> <li>T</li> <li>E</li> <li>R</li><li></li>           
                        <li>S</li> <li>E</li> <li>R</li> <li>V</li> <li>I</li> <li>C</li> <li>E</li> <li>S</li><li></li>
                        <li>C</li><li>E</li> <li>N</li> <li>T</li> <li>R</li> <li>E</li>
                    </ul>
               </div>
            </div>
        </div>
    </footer>
<!-- end of footer><!-->


<script src = "js/Jquery.js"></script>
<script src = "js/bootstrap.min.js"></script>
	
</body>
</html>

