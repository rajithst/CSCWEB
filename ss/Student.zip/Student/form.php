<?php

$error='';

if(isset($_POST['Submit'])){
	if(empty($_POST['username']) || empty($_POST['passwrd'])){
		$error="Username or Password is Invalid";
	}
	else{
		$user=$_POST['username'];
		$pass=$_POST['passwrd'];

		//connect with database
		$connection = mysqli_connect("localhost", "root", "");
		$database = mysqli_select_db($connection, "csc-ucsc");
		$query = mysqli_query($connection, "SELECT * FROM student WHERE S_Email='$user' AND S_Password='$pass' ");

		$rows = mysqli_num_rows($query);
		if($rows == 1){
			header("Location: Home.html");
		}
		else{
			$error = "Username or Password is Invalid";
		}
		mysqli_close($connection);
	}
}

?>